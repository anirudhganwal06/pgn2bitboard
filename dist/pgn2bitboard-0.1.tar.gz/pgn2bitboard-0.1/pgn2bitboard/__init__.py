from pgn2bitboard.main import choosePositions
from pgn2bitboard.main import winner
from pgn2bitboard.main import pgn2fen
from pgn2bitboard.main import fen2bitboard
from pgn2bitboard.main import pgn2bitboard
